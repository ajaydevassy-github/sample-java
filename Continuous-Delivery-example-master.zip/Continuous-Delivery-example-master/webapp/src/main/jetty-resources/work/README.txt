Temp-dir for Jetty. War-en pakkes ut her ved kjøretid.

Se her: http://docs.codehaus.org/display/JETTY/Temporary+Directories