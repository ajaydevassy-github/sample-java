INSERT INTO `bekkopen`.`Artifact` (`groupId`, `artifactId`, `version`, `packaging`) VALUES ('no.bekk.bekkopen.cde', 'webapp', '0.1-SNAPSHOT', 'zip');
INSERT INTO `bekkopen`.`Artifact` (`groupId`, `artifactId`, `version`, `packaging`) VALUES ('no.bekk.bekkopen.cde', 'core', '0.1-SNAPSHOT', 'jar');
INSERT INTO `bekkopen`.`Artifact` (`groupId`, `artifactId`, `version`, `packaging`) VALUES ('no.bekk.bekkopen.cde', 'database', '0.1-SNAPSHOT', 'jar');
INSERT INTO `bekkopen`.`Artifact` (`groupId`, `artifactId`, `version`, `packaging`) VALUES ('no.bekk.bekkopen.cde', 'parent', '0.1-SNAPSHOT', 'pom');
commit;
