Example config
==============

* deploy.config: Config for the ../scripts/deploy.sh script.
* webapp.properties: Property file for the webapp. It is filtered and included in the webapp when you build the webapp.
* secret.properties.example: Example property file with "secret" properties. Must be present on every environment you deploy to.
