package no.bekk.bekkopen.cde.feature;

public interface Enabled {
    boolean isEnabled();
}
